Mini Blockchain in Python

A basic blockchain implementation built in Python for learning purposes. This project shows the main ideas behind blockchain including hashing, mining with proof-of-work, and checking if the chain is valid.


What It Does

- Creates blocks with secure hashing using SHA-256
- Mines blocks using proof-of-work with changeable difficulty
- Checks if the blockchain has been tampered with
- Creates the first genesis block
- Handles transaction data between users

What You Need

- Python 3.x
- Only Python's built-in libraries (no extra installations)

How To Run
python main.py

When you run it, the program will:

1. Start a new blockchain with the first block
2. Mine and add three blocks with transactions
3. Show the entire blockchain
4. Check if the chain is valid
5. Show how it detects when someone tries to change data

Technical Info

- Hashing: Uses SHA-256
- Mining Difficulty: Needs 2 zeros at the start of the hash
- Mining Method: Tries different nonce values until it finds a valid hash
- Validation: Makes sure blocks are properly connected and not changed

About The Screenshots

- Shows how blocks are mined with nonce values
- Shows all blocks with their details
- Shows the chain passing the validity check
- Shows what happens when block data is changed

Author: axilISNOTBUSY