import datetime
import hashlib
import time

class Block:
    def __init__(self, index, timestamp, data, previous_hash):
        self.index = index
        self.timestamp = timestamp
        self.data = data
        self.previous_hash = previous_hash
        self.nonce = 0
        self.hash = self.calculate_hash()

    def calculate_hash(self):
        data = (
            str(self.index)
            + str(self.timestamp)
            + str(self.data)
            + str(self.previous_hash)
            + str(self.nonce)
        )
        return hashlib.sha256(data.encode()).hexdigest()

    def mine_block(self, difficulty):
        target = '0' * difficulty
        start = time.time()
        while not self.hash.startswith(target):
            self.nonce += 1
            self.hash = self.calculate_hash()
        duration = time.time() - start
        print(f"Mined block {self.index} with nonce={self.nonce} in {duration:.4f}s")

class Blockchain:
    def __init__(self):
        self.difficulty = 2
        self.chain = [self.create_genesis_block()]

    def create_genesis_block(self):
        genesis = Block(0, datetime.datetime.now(), "Genesis Block", "0")
        genesis.mine_block(self.difficulty)
        return genesis
    
    def get_latest_block(self):
        return self.chain[-1]
    
    def add_block(self, block):
        block.previous_hash = self.get_latest_block().hash
        block.mine_block(self.difficulty)
        self.chain.append(block)
    
    def is_chain_valid(self):
        for i in range(1, len(self.chain)):
            current_block = self.chain[i]
            previous_block = self.chain[i-1]
            
            if current_block.hash != current_block.calculate_hash():
                return False
                
            if current_block.previous_hash != previous_block.hash:
                return False
                
            if not current_block.hash.startswith('0' * self.difficulty):
                return False
                
        return True

blockchain = Blockchain()

block1 = Block(1, datetime.datetime.now(), {"amount":10, "sender": "alice", "receiver": "bob"}, "")
blockchain.add_block(block1)

block2 = Block(2, datetime.datetime.now(), {"amount": 5, "sender": "bob", "receiver": "charlie"}, "")
blockchain.add_block(block2)

block3 = Block(3, datetime.datetime.now(), {"amount": 7, "sender": "alice", "receiver": "charlie"}, "")
blockchain.add_block(block3)

for block in blockchain.chain:
    print(f"Block: {block.index}")
    print(f"Timestamp: {block.timestamp}")
    print(f"Data: {block.data}")
    print(f"Previous Hash: {block.previous_hash}")
    print(f"Hash: {block.hash}")
    print()

print("Blockchain valid:", blockchain.is_chain_valid())

blockchain.chain[1].data = {"amount": 1000, "sender": "hacker", "receiver": "bob"}
print("After tampering, blockchain valid:", blockchain.is_chain_valid())